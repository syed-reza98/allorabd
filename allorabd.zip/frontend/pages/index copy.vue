<script setup lang="ts">
const { data: categories } = await useLarafetch("/api/categories");
const { data: products } = await useLarafetch("/api/products");
const { isLoggedIn } = useAuth();
</script>

<template>
  <NuxtLayout name="main-layout">
    <div class="hero h-96" style="background-image: url(https://daisyui.com/images/stock/photo-1507358522600-9f71e620c44e.jpg);">
      <div class="hero-overlay bg-opacity-60"></div>
      <div class="hero-content text-center text-neutral-content">
        <div class="max-w-md">
          <h1 class="mb-5 text-5xl font-bold">Hello there</h1>
          <p class="mb-5">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
          <!-- <button class="btn btn-primary">Get Started</button> -->
        </div>
      </div>
    </div>
    <div>
      <pre>{{ categories }}</pre>
      <pre>{{ products }}</pre>
    </div>
  </NuxtLayout>
</template>

