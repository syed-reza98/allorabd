<template>
  <div>
    <Head>
      <Title>Laravel</Title>
    </Head>

    <slot />
  </div>
</template>
