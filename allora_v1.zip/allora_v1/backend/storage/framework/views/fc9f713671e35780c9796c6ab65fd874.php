<div class="flex items-center gap-4">

    <img src="<?php echo e(asset('img/logo.svg')); ?>" class="h-10" alt="Filament Demo" />

    <h1 class="text-2xl text-gray-400">
        <?php echo e(env('APP_NAME')); ?>

    </h1>

</div>
<?php /**PATH G:\filament-demo-main\allora_v1\backend\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>