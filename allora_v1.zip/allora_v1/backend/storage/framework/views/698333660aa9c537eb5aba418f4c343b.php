<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('livewire-ui-spotlight');

$__html = app('livewire')->mount($__name, $__params, 'lw-1094672627-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH G:\filament-demo-main\allora_v1\backend\storage\framework\views/29f10b3a3ae1f582e26d0c78ff3a3419.blade.php ENDPATH**/ ?>